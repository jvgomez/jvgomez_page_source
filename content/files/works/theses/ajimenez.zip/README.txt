Arduino: Arduino code to control the robots.
Send: C code to send serial commands to the robots.
Vision: C++ code OpenCV based to localize the robots 