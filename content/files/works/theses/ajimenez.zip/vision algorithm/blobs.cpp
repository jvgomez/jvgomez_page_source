
// Adrian Jimenez Camara. Universidad Carlos III de Madrid

#include <iostream>
#include <iomanip>

#if (defined(_WIN32) || defined(__WIN32__) || defined(__TOS_WIN__) || defined(__WINDOWS__) || (defined(__APPLE__) & defined(__MACH__)))
#include <cv.h>
#include <highgui.h>
#else
#include <opencv/cv.h>
#include <opencv/highgui.h>
#endif

#include <stdio.h>
#include "math.h"
#include <cvblob.h>

#include <time.h>
#include <sys/time.h>


using namespace cvb;

// Returns a - b in seconds

double timeval_diff(struct timeval *a, struct timeval *b)
{
  return
    (double)(a->tv_sec + (double)a->tv_usec/1000000) -
    (double)(b->tv_sec + (double)b->tv_usec/1000000);
}

//Function to draw a rectangle from three points

void drawBox( CvArr* img, CvPoint& p1, CvPoint& p2, CvPoint& p3 )
{
	if (abs(p2.x-p1.x) > 0.01 && abs(p2.y-p1.y) > 0.01){
	
	//Ecuation of the line that passes through p1 and p2
	double ax =(double) 1/(p2.x-p1.x);
	double ay =(double)  -1/(p2.y-p1.y);
	double ai =(double) (-p1.x*ax) + (double) (-p1.y*ay);
	
	//Slope of the line
	double mr = -ax/ay;
	//Slope of the perpendicular line
	double ms = ay/ax;
	

	//Perpendicular line to the previous one that passes through p1
	//Perpendicular line to the previous one that passes through p2
	double ax_per = -ms;
	double ai_per1 = (double) (ms*p1.x) - p1.y;
	double ai_per2 = (double) (ms*p2.x) - p2.y;
	
	//Parallel line to the previous one that passes through p3
	double ax_par = -mr;
	double ai_par = (double) (mr*p3.x) - p3.y;
	
	//We solve the equation
	CvPoint p_aux1, p_aux2;
	p_aux1.x = (-ai_par+ai_per1)/(ax_par-ax_per);
	p_aux1.y = -ai_par-ax_par*p_aux1.x;
	
	p_aux2.x = (-ai_par+ai_per2)/(ax_par-ax_per);
	p_aux2.y = -ai_par-ax_par*p_aux2.x;
	
	
	//We draw the rectangle
	CvPoint rect_points[1][4];
	rect_points[0][0] = p1;
	rect_points[0][1] = p2;
	rect_points[0][2] = p_aux2;
	rect_points[0][3] = p_aux1;
	
	CvPoint* ppt[1] = { rect_points[0] };
	int npt[] = { 4 };
	
	cvFillPoly( img, ppt, npt, 1, cvScalar(0, 0, 0, 0), 8, 0);
 }
	
}

//Function to compute the euclidean distance between two points

double eu_distance(const CvPoint& point_one, const CvPoint& point_two)
{
return sqrt(double((point_one.x - point_two.x) * (point_one.x -
point_two.x) +
(point_one.y - point_two.y) * (point_one.y - point_two.y)) );
}

//Function to obtain the average value of a image data matrix

int avg(IplImage* img){
	double mean = 0;
	
	for( int y=0; y<img->height; y++ ) {
	uchar* ptr = (uchar*) ( img->imageData + y * img->widthStep );
	
	for( int x=0; x<img->width; x++ ) {
	
	mean = mean + ptr[x];	
	}
	}
	mean = mean / (img->height * img->width);
	return int(mean);
	
}

//Main program

int main()
{	
  printf( "Detector program\n");
  
  
  //Initializations	
  CvTracks tracks, tracks2;

  cvNamedWindow("Object_tracking", CV_WINDOW_AUTOSIZE);
  cvNamedWindow("Map", CV_WINDOW_AUTOSIZE);
  cvNamedWindow("Map 2", CV_WINDOW_AUTOSIZE);

  CvCapture *capture = cvCaptureFromCAM(1); //0 if computer webcam. 1 if external USB cam
  cvGrabFrame(capture);
  IplImage *img = cvRetrieveFrame(capture);

  CvSize imgSize = cvGetSize(img);

  IplImage *frame = cvCreateImage(imgSize, img->depth, img->nChannels);
  IplImage *frame_cal = cvCreateImage(imgSize, img->depth, img->nChannels);
  IplImage *frame_cal2 = cvCreateImage(imgSize, img->depth, img->nChannels);
  IplImage *map = cvCreateImage(imgSize, img->depth, img->nChannels);
  IplImage *map2 = cvCreateImage(imgSize, img->depth, img->nChannels);
  
  IplConvKernel* morphKernel = cvCreateStructuringElementEx(5, 5, 1, 1, CV_SHAPE_RECT, NULL);

  unsigned int blobNumber = 0;

  bool quit = false;
  bool calibration = false;
  
  //Calibration points
  CvPoint calibration_pt1, calibration_pt2;
  CvPoint text_point;
  
  cvNamedWindow( "Calibration", CV_WINDOW_AUTOSIZE );  
  
  double hue_value, sat_value, val_value;
  double r1_value, g1_value, b1_value;
  double hue_value2, sat_value2, val_value2;
  double r2_value, g2_value, b2_value;
  
  //Initialization of font code
  CvFont font;

  cvInitFont( &font, CV_FONT_VECTOR0, 1, 1, 0, 2.0, CV_AA);  
  
  int width, height;
  
  int cal_counter = 0;
  int map_number = 1;
  
  int tol = 25, tol2= 60;
  
  //Percentage counters
	double per_count1 = 0;
	double per_count2 = 0;
  
  //Main loop
  while (!quit&&cvGrabFrame(capture))
  {
	  
	IplImage *img = cvRetrieveFrame(capture);
	cvConvertScale(img, frame, 1, 0);
		
		//Calibration phase
		
		if (calibration == 0){	
			
		cvConvertScale(img, frame_cal, 1, 0);
		cvConvertScale(img, frame_cal2, 1, 0);
		
		calibration_pt1.x = 220; 
		calibration_pt1.y = 50; 

		calibration_pt2.x = 420;
		calibration_pt2.y = 150;
		
		text_point.x = 170;
		text_point.y = 220;
		
		
		//Calibration Text
		if (cal_counter == 0){
		cvPutText(frame_cal, "Calibration phase", text_point, &font,CV_RGB(255,255,255) ); 
		text_point.x = 35;
		text_point.y = 260;
		cvPutText(frame_cal, "Please put the label in the rectangle", text_point, &font,CV_RGB(255,255,255) ); 
		text_point.x = 50;
		text_point.y = 290;
		cvPutText(frame_cal, "above and press C for calibration", text_point, &font,CV_RGB(255,255,255) );
		

		
		} else if (cal_counter == 1){
		text_point.x = 180;
		text_point.y = 260;
		cvPutText(frame_cal, "Second calibration", text_point, &font,CV_RGB(255,255,255) );
		}
		
		//Drawing calibration rectangle
		cvRectangle( frame_cal, calibration_pt1 , calibration_pt2 , CV_RGB(255,255,255), 3, 8, 0 ); 

		cvShowImage("Calibration", frame_cal);	
		
	
		 
		//Calibration values
		char k = cvWaitKey(10)&0xff;
		switch (k)
		{
		  case 27:
		  case 'c':
		  case 'C':
		  
			
			width = calibration_pt2.x - calibration_pt1.x;
			height = calibration_pt2.y - calibration_pt1.y; 
			
			cvSetImageROI( frame_cal2, cvRect( calibration_pt1.x + 5, calibration_pt1.y + 5, width - 5, height - 5 )); 
			
			IplImage* hsv_frame = cvCreateImage(cvGetSize(frame_cal2), IPL_DEPTH_8U, 3);
			cvCvtColor(frame_cal2, hsv_frame, CV_BGR2HSV);
			
			CvSize size = cvGetSize(frame_cal2);
			int depth = frame_cal2->depth;
			IplImage* hue = cvCreateImage(size, depth, 1);
			IplImage* sat = cvCreateImage(size, depth, 1);
			IplImage* val = cvCreateImage(size, depth, 1);
			
			IplImage* r = cvCreateImage(size, depth, 1);
			IplImage* g = cvCreateImage(size, depth, 1);
			IplImage* b = cvCreateImage(size, depth, 1);
			
			cvSplit(hsv_frame, hue, sat, val, 0);
			cvSplit(frame_cal2, r, g, b, 0);
			
			cvResetImageROI(frame_cal2);

			
			if (cal_counter == 0){
			
			hue_value = avg(hue);
			sat_value = avg(sat);
			val_value = avg(val);
			
			r1_value = avg(r);
			g1_value = avg(g);
			b1_value = avg(b);
			
			printf( "Calibration 1\n");
			std::cout <<"Hue  \n"<<hue_value<<std::endl;
			std::cout <<"Saturation  \n"<<sat_value<<std::endl;
			std::cout <<"Value  \n"<<val_value<<std::endl;
			cal_counter++;
			} else if (cal_counter == 1){
					
			hue_value2 = avg(hue);
			sat_value2 = avg(sat);
			val_value2 = avg(val);
			
			r2_value = avg(r);
			g2_value = avg(g);
			b2_value = avg(b);
			
			printf( "Calibration 2\n");
			std::cout <<"Hue  \n"<<hue_value2<<std::endl;
			std::cout <<"Saturation  \n"<<sat_value2<<std::endl;
			std::cout <<"Value  \n"<<val_value2<<std::endl;
			
			calibration = true;
			cvDestroyWindow("Calibration");
			
			cvReleaseImage(&hsv_frame);
			cvReleaseImage(&hue);
			cvReleaseImage(&sat);
			cvReleaseImage(&val);
			}
			
		}

	}
	
	if (calibration == 1){	
		
	per_count1++;
		
	//Time measure initializations
	struct timeval t_ini, t_fin;
	double secs;	
	int secs_counter = 0;
	
	//Start measuring the time
	gettimeofday(&t_ini, NULL);
	
	//Initialize segmentation frames
    IplImage *segmentated = cvCreateImage(imgSize, 8, 1);
    IplImage *segmentated2 = cvCreateImage(imgSize, 8, 1);
    
    //Intilialize map to white color
    cvSet(map, CV_RGB(255,255,255),NULL);
    cvSet(map2, CV_RGB(255,255,255),NULL);
    
    //Map2 black frame 
    CvPoint pt_ini, pt_final;
    pt_ini.x = 0; pt_ini.y = 0;
    pt_final.x = 639; pt_final.y = 479;
    cvRectangle( map2, pt_ini , pt_final , CV_RGB(0,0,0), 3, 8, 0 ); 
    
    // Detecting pixels:
    
    IplImage* hsv_frame = cvCreateImage(cvGetSize(frame), IPL_DEPTH_8U, 3);
    IplImage* hsv_frame2 = cvCreateImage(cvGetSize(frame), IPL_DEPTH_8U, 3);
    
    CvScalar hsv_min = cvScalar(hue_value - tol, sat_value - tol2, val_value - tol2);
	CvScalar hsv_max = cvScalar(hue_value + tol, sat_value + tol2, val_value + tol2);
	
	CvScalar hsv_min2 = cvScalar(hue_value2 - tol, sat_value2 - tol2, val_value2 - tol2);
	CvScalar hsv_max2 = cvScalar(hue_value2 + tol, sat_value2 + tol2, val_value2 + tol2);
	
	//Segmentation in HSV color space
	
	cvCvtColor(frame, hsv_frame, CV_BGR2HSV);
	cvCvtColor(frame, hsv_frame2, CV_BGR2HSV);
	cvInRangeS(hsv_frame, hsv_min, hsv_max, segmentated);
	cvInRangeS(hsv_frame2, hsv_min2, hsv_max2, segmentated2);


    cvMorphologyEx(segmentated, segmentated, NULL, morphKernel, CV_MOP_OPEN, 1);
	cvMorphologyEx(segmentated2, segmentated2, NULL, morphKernel, CV_MOP_OPEN, 1);
	
	//cvShowImage("segmentated1", segmentated); 
    //cvShowImage("segmentated2", segmentated2);

    IplImage *labelImg = cvCreateImage(cvGetSize(frame), IPL_DEPTH_LABEL, 1);
	IplImage *labelImg2 = cvCreateImage(cvGetSize(frame), IPL_DEPTH_LABEL, 1);
	
    CvBlobs blobs, blobs2;
    unsigned int result = cvLabel(segmentated, labelImg, blobs);
    unsigned int result2 = cvLabel(segmentated2, labelImg2, blobs2);
    
    cvFilterByArea(blobs, 500, 1000000);
    cvRenderBlobs(labelImg, blobs, frame, frame, CV_BLOB_RENDER_BOUNDING_BOX);
    cvUpdateTracks(blobs, tracks, 200., 5);
    cvRenderTracks(tracks, frame, frame, CV_TRACK_RENDER_ID|CV_TRACK_RENDER_BOUNDING_BOX);
    
    cvFilterByArea(blobs2, 500, 1000000);
    cvRenderBlobs(labelImg2, blobs2, frame, frame, CV_BLOB_RENDER_BOUNDING_BOX);
    cvUpdateTracks(blobs2, tracks2, 200., 5);
    cvRenderTracks(tracks2, frame, frame, CV_TRACK_RENDER_ID|CV_TRACK_RENDER_BOUNDING_BOX);
        
        
    int robot1x[3], robot1y[3], robot2x[3], robot2y[3];
    int i=1;
    /*
    CvPoint *points[3];
    
    for (i = 0; i < 3; i++)
    {
    points[i] = (CvPoint *)malloc(sizeof(CvPoint));
    }
	*/
	CvPoint p1,p2,p3;
    for (CvBlobs::const_iterator it=blobs.begin(); it!=blobs.end(); ++it)
	{
	
	double moment10 = it->second->m10;
	double moment01 = it->second->m01;
	double area = it->second->area;
		
		//Variable for holding position
		int x1;
		int y1;
		//Calculating the current position
		x1 = moment10/area;
		y1 = moment01/area;
		//Mapping to the screen coordinates
		int x=(int)(x1);
		int y=(int)(y1);
		
		//Printing the position information
		//cout<<"Point"<<endl;
		//std::cout <<"X: "<<x<<" Y: "<<y<<std::endl;
		
		//printf( "Robot 1\n");
		//std::cout <<"Blob: "<<i<<" X: "<<x<<" Y: "<<y<<std::endl;
		robot1x[i] = x;
		robot1y[i] = y;
		
		CvPoint pt1;
		pt1.x=x;
		pt1.y=y;
		cvCircle( map, pt1, 15 , CV_RGB(0,0,0), 3, 8, 0 ); //Dibujamos el rectangulo
		
		//std::cout << filename.str() << " saved!" << std::endl;
		if(i==1){
			
			p1=pt1;
			}
			else if (i==2){
				p2=pt1;
				}
			else if (i==3){
				p3=pt1;
				}
		i++;
	}
	
	CvPoint centroid1;
	centroid1.x = ((robot1x[1]+robot1x[2]+robot1x[3])/3);
	centroid1.y = ((robot1y[1]+robot1y[2]+robot1y[3])/3);
	
	if (i==4){
		per_count2++;
		
		int j [3] = { 8,4,4 }; 
		int min=eu_distance(p1,p2);
		if (eu_distance(p1,p3)<min) { 
			min= eu_distance(p1,p3);
			j[0]=4;j[1]=8;j[2]=4;
			drawBox(map2, p1, p3, p2);
			cvLine(map, centroid1, p2, cvScalar(0, 0, 0, 0), 5, 8, 0);
			//cvRectangle(map2, p1, p2, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		} else if (eu_distance(p2,p3)<min) {
			min= eu_distance(p2,p3);
			j[0]=4;j[1]=4;j[2]=8;
			drawBox(map2, p2, p3, p1);
			cvLine(map, centroid1, p1, cvScalar(0, 0, 0, 0), 5, 8, 0);
			//cvRectangle(map2, p1, p2, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		} else {
			drawBox(map2, p1, p2, p3);
			cvLine(map, centroid1, p3, cvScalar(0, 0, 0, 0), 5, 8, 0);
			//cvRectangle(map2, p2, p3, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		}
		cvLine(map, p1, p2, cvScalar(0, r1_value, g1_value, b1_value), j[0], 8, 0);
		cvLine(map, p1, p3, cvScalar(0, r1_value, g1_value, b1_value), j[1], 8, 0);
		cvLine(map, p2, p3, cvScalar(0, r1_value, g1_value, b1_value), j[2], 8, 0);
		//cvRectangle(map2, p1, p2, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		
		}
	
	
	
	
	if (centroid1.x > 0.1 && centroid1.x < 1000){
		
	cvCircle( map, centroid1, 3 , CV_RGB(0,0,0), 5, 8, 0 ); //Dibujamos el rectangulo
	
		
	printf( "Robot 1 -->"); 
	std::cout <<" X: "<<centroid1.x<<" Y: "<<centroid1.y<<std::endl;
	printf( "\n"); 
	printf( "Real coordinates"); 
		std::cout <<" X: "<<centroid1.x*60/640<<"cm Y: "<<centroid1.y*50/480<<"cm"<<std::endl;
	printf( "\n"); 
	printf( "\n"); 
	robot1x[1]=0;robot1x[2]=0;robot1x[3]=0;
	robot1y[1]=0;robot1y[2]=0;robot1y[3]=0;
	}
	
	 ///////////////////////////////////////////////////////////////////////////////////       
    i=1;
    /*
    CvPoint *points[3];
    
    for (i = 0; i < 3; i++)
    {
    points[i] = (CvPoint *)malloc(sizeof(CvPoint));
    }
	*/
	//CvPoint p1,p2,p3;
    for (CvBlobs::const_iterator it=blobs2.begin(); it!=blobs2.end(); ++it)
	{
	
	double moment10 = it->second->m10;
	double moment01 = it->second->m01;
	double area = it->second->area;
		
		//Variable for holding position
		int x1;
		int y1;
		//Calculating the current position
		x1 = moment10/area;
		y1 = moment01/area;
		//Mapping to the screen coordinates
		int x=(int)(x1);
		int y=(int)(y1);
		
		//Printing the position information
		//cout<<"Point"<<endl;
		//std::cout <<"X: "<<x<<" Y: "<<y<<std::endl;
		
		//printf( "Robot 2\n");
		//std::cout <<"Blob: "<<i<<" X: "<<x<<" Y: "<<y<<std::endl;
		
		robot2x[i] = x;
		robot2y[i] = y;
		
		CvPoint pt1;
		pt1.x=x;
		pt1.y=y;
		cvCircle( map, pt1, 15 , CV_RGB(0,0,0), 3, 8, 0 ); //Dibujamos el rectangulo
		
		//std::cout << filename.str() << " saved!" << std::endl;
		if(i==1){
			
			p1=pt1;
			}
			else if (i==2){
				p2=pt1;
				}
			else if (i==3){
				p3=pt1;
				}
		i++;
	}
		
	CvPoint centroid2;
	centroid2.x = ((robot2x[1]+robot2x[2]+robot2x[3])/3);
	centroid2.y = ((robot2y[1]+robot2y[2]+robot2y[3])/3);
	
	if (i==4){
		
		per_count2++;
		
		int j [3] = { 8,4,4 }; 
		int min=eu_distance(p1,p2);
		if (eu_distance(p1,p3)<min) {
			min= eu_distance(p1,p3);
			j[0]=4;j[1]=8;j[2]=4;
			drawBox(map2, p1, p3, p2);
			cvLine(map, centroid2, p2,cvScalar(0, 0, 0, 0), 5, 8, 0);
			//cvRectangle(map2, p1, p2, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		} else if (eu_distance(p2,p3)<min) {
			min= eu_distance(p2,p3);
			j[0]=4;j[1]=4;j[2]=8;
			drawBox(map2, p2, p3, p1);
			cvLine(map, centroid2, p1, cvScalar(0, 0, 0, 0), 5, 8, 0);
			//cvRectangle(map2, p1, p2, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		} else {
			drawBox(map2, p1, p2, p3);
			cvLine(map, centroid2, p3, cvScalar(0, 0, 0, 0), 5, 8, 0);
			//cvRectangle(map2, p2, p3, cvScalar(0, 0, 0, 0), CV_FILLED, 8, 0);
		}
		cvLine(map, p1, p2, cvScalar(0, r2_value, g2_value, b2_value), j[0], 8, 0);
		cvLine(map, p1, p3, cvScalar(0, r2_value, g2_value, b2_value), j[1], 8, 0);
		cvLine(map, p2, p3, cvScalar(0, r2_value, g2_value, b2_value), j[2], 8, 0);
		
		}
		
	//cvPolyLine(map2, (p1,p2,p3), 1, cvScalar(0, 0, 0, 0), 1, 8, 0);

	
	if (centroid2.x > 0.1 && centroid2.x < 1000){
		
	cvCircle( map, centroid2, 3 , CV_RGB(0,0,0), 5, 8, 0 ); //Dibujamos el rectangulo
	
	printf( "Robot 2 -->"); 
	std::cout <<" X: "<<centroid2.x<<" Y: "<<centroid2.y<<std::endl;
	printf( "\n"); 
	printf( "Real coordinates"); 
		std::cout <<" X: "<<centroid2.x*60/640<<"cm Y: "<<centroid2.y*50/480<<"cm"<<std::endl;
	printf( "\n"); 
	printf( "\n"); 
	robot2x[1]=0;robot2x[2]=0;robot2x[3]=0;
	robot2y[1]=0;robot2y[2]=0;robot2y[3]=0;
	}
	
    cvShowImage("Object_tracking", frame);
    cvShowImage("Map", map);
	cvShowImage("Map2", map2);
	
    /*std::stringstream filename;
    filename << "redobject_" << std::setw(5) << std::setfill('0') << frameNumber << ".png";
    cvSaveImage(filename.str().c_str(), frame);*/

	
    char k = cvWaitKey(10)&0xff;
    switch (k)
    {
      case 27:
      case 'q':
      case 'Q':
        quit = true;
        break;
      case 's':
      case 'S':
      /*
        for (CvBlobs::const_iterator it=blobs.begin(); it!=blobs.end(); ++it)
        {
          std::stringstream filename;
          filename << "redobject_blob_" << std::setw(5) << std::setfill('0') << blobNumber << ".png";
          cvSaveImageBlob(filename.str().c_str(), img, it->second);
          blobNumber++;

          std::cout << filename.str() << " saved!" << std::endl;
        }
        break;*/
        std::stringstream filename;
        filename << "map" << std::setw(5) << std::setfill('0') << map_number << ".png";
        cvSaveImage(filename.str().c_str(),map);
        map_number++;

    }

    cvReleaseBlobs(blobs);
    cvReleaseBlobs(blobs2);
    
	//cvReleaseImage(&img);
	cvReleaseImage(&segmentated);
	cvReleaseImage(&segmentated2);
	cvReleaseImage(&hsv_frame);
	cvReleaseImage(&hsv_frame2);
	cvReleaseImage(&labelImg);
	cvReleaseImage(&labelImg2);

    //frameNumber++;
    /*
    //Finish measuring the time
    gettimeofday(&t_fin, NULL);
    secs = timeval_diff(&t_fin, &t_ini);
    printf("%.16g\n", secs * 1000.0);*/
  }
}

  printf( "Tracking percentage "); 
  printf("%16g\n", 1/(per_count1/(per_count2/2)));
  
  cvReleaseStructuringElement(&morphKernel);
  cvReleaseImage(&frame);

  cvDestroyWindow("Object_tracking");

  return 0;
}
